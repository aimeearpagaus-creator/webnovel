# Web Novel Starter (Next.js + Tailwind + Supabase + Stripe)

Features:
- Chapters (free/premium) with paywall
- Upload/display art (Supabase Storage)
- "Buy me a coffee" (Stripe one-time or Ko-fi link)
- Member chat (Supabase Realtime)
- Subscriptions (Stripe Checkout + webhook -> marks user `is_pro`)

## 1) Create services
- **Supabase** project → get `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
- **Stripe** account → create:
  - a **recurring Price** (for membership) → `STRIPE_PRICE_ID`
  - a **one-time Price** (for coffee) → `STRIPE_DONATION_PRICE_ID`

## 2) Supabase schema
Run these SQL snippets in Supabase SQL editor:

```sql
-- Profiles
create table if not exists public.profiles (
  id uuid primary key references auth.users on delete cascade,
  email text unique,
  is_pro boolean default false,
  created_at timestamp with time zone default now()
);
alter table public.profiles enable row level security;
create policy "self read" on public.profiles for select using (auth.uid() = id);
create policy "self update" on public.profiles for update using (auth.uid() = id);

-- Insert profile on signup
create or replace function public.handle_new_user() returns trigger as $$
begin
  insert into public.profiles (id, email) values (new.id, new.email);
  return new;
end;
$$ language plpgsql security definer;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users for each row execute function public.handle_new_user();

-- Chat messages (members only)
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users on delete cascade,
  content text not null,
  created_at timestamp with time zone default now()
);
alter table public.messages enable row level security;
create policy "members can read" on public.messages for select using (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_pro = true)
);
create policy "members can write" on public.messages for insert with check (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_pro = true)
);

-- (Optional) Chapters table if you want DB-driven chapters
create table if not exists public.chapters (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  summary text,
  content text,
  is_premium boolean default false,
  created_at timestamp with time zone default now()
);
alter table public.chapters enable row level security;
create policy "anyone read free, members read premium" on public.chapters for select using (
  is_premium = false OR exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_pro = true)
);
```

**Storage for art**: create a public bucket `art` (or keep private and sign URLs).

## 3) Environment
Copy `.env.example` to `.env.local` and fill values. Also set `SITE_URL` to your deployed URL or `http://localhost:3000`.

Optionally set `KOFI_URL` to your Ko-fi page; otherwise Stripe one-time tip is used.

## 4) Stripe webhook
In Stripe CLI or Dashboard, set a webhook to:
```
POST {SITE_URL}/api/stripe-webhook
```
Listen to event `checkout.session.completed`.
This handler marks `profiles.is_pro = true` for the buyer's email.

For production, consider a separate service key or Supabase service role JWT instead of anon key.

## 5) Run locally
```bash
npm install
npm run dev
```

## 6) Replace mock chapter data
- Swap `/app/chapters/page.tsx` and `/app/chapters/[slug]/page.tsx` to fetch from `public.chapters` via Supabase.
- Or edit the static array to start.

## Notes
- This is a minimal starter. You can enhance: SEO, author dashboard to create chapters, image uploader, role-based moderation for chat, etc.
- Always secure your keys. For server-to-Supabase updates, prefer a service role key via an Edge Function or serverless function.

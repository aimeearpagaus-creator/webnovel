'use client';
import { useState } from "react";

export default function Paywall({ isPro }: { isPro: boolean }) {
  const [loading, setLoading] = useState(false);
  const startCheckout = async () => {
    setLoading(true);
    const res = await fetch('/api/create-checkout-session', { method: 'POST' });
    const { url } = await res.json();
    window.location.href = url;
  };
  if (isPro) return null;
  return (
    <div className="rounded-2xl border p-6 bg-white shadow-sm">
      <h3 className="text-lg font-semibold">Premium chapter</h3>
      <p className="text-sm mt-2">Become a member to unlock this chapter.</p>
      <button onClick={startCheckout} disabled={loading} className="mt-4 px-4 py-2 rounded-xl bg-slate-900 text-white">
        {loading ? 'Redirecting…' : 'Subscribe to unlock'}
      </button>
    </div>
  );
}

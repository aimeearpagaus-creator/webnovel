import Link from "next/link";

export default function ChapterCard({ chapter }: { chapter: any }) {
  return (
    <Link href={`/chapters/${chapter.slug}`} className="block rounded-2xl border p-5 bg-white shadow-sm hover:shadow-md transition">
      <div className="text-xs uppercase tracking-wide text-slate-500">{chapter.is_premium ? 'Premium' : 'Free'}</div>
      <h3 className="text-xl font-semibold mt-1">{chapter.title}</h3>
      <p className="text-sm mt-2 line-clamp-2">{chapter.summary}</p>
    </Link>
  );
}

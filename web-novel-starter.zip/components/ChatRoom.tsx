'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

type Message = { id: string; content: string; created_at: string; user_id: string };

export default function ChatRoom({ canChat }: { canChat: boolean }) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from('messages').select('*').order('created_at', { ascending: true }).limit(200);
      setMessages(data || []);
    };
    load();
    const channel = supabase.channel('room').on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, (payload) => {
      if (payload.new) setMessages((m) => [...m, payload.new as Message]);
    }).subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  const send = async () => {
    if (!input.trim() || !canChat) return;
    await supabase.from('messages').insert({ content: input });
    setInput('');
  };

  return (
    <div className="rounded-2xl border bg-white shadow-sm p-4">
      <div className="h-72 overflow-y-auto space-y-2 mb-3">
        {messages.map(m => (
          <div key={m.id} className="text-sm"><span className="text-slate-500 mr-2">{new Date(m.created_at).toLocaleTimeString()}</span>{m.content}</div>
        ))}
      </div>
      <div className="flex gap-2">
        <input value={input} onChange={(e)=>setInput(e.target.value)} placeholder={canChat ? 'Type a message…' : 'Members only'} className="flex-1 border rounded-xl px-3 py-2"/>
        <button onClick={send} disabled={!canChat} className="px-4 py-2 rounded-xl bg-slate-900 text-white">Send</button>
      </div>
    </div>
  );
}

import Image from "next/image";
import Link from "next/link";

export default function Home() {
  return (
    <div className="grid gap-8 md:grid-cols-2 items-center">
      <div>
        <h1 className="text-4xl font-extrabold">Your Web Novel</h1>
        <p className="mt-4 text-slate-600">Publish chapters, upload art, and build a community with memberships, chat, and a coffee button.</p>
        <div className="mt-6 flex gap-3">
          <Link href="/chapters" className="px-4 py-2 rounded-xl bg-slate-900 text-white">Read chapters</Link>
          <Link href="/members" className="px-4 py-2 rounded-xl border">Members area</Link>
        </div>
      </div>
      <div className="rounded-2xl border bg-white shadow-sm p-4">
        <Image src="https://picsum.photos/800/500" alt="Cover art" width={800} height={500} className="rounded-xl"/>
      </div>
    </div>
  );
}

'use client';
import { supabase } from '@/lib/supabaseClient';
import { useState } from 'react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);

  const send = async () => {
    const { error } = await supabase.auth.signInWithOtp({ email });
    if (!error) setSent(true);
    else alert(error.message);
  };
  return (
    <div className="max-w-md mx-auto rounded-2xl border p-6 bg-white shadow-sm">
      <h1 className="text-2xl font-bold mb-2">Login</h1>
      {sent ? <p>Check your email for the magic link.</p> : (
        <div className="space-y-3">
          <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="you@example.com" className="w-full border rounded-xl px-3 py-2"/>
          <button onClick={send} className="px-4 py-2 rounded-xl bg-slate-900 text-white">Send magic link</button>
        </div>
      )}
    </div>
  );
}

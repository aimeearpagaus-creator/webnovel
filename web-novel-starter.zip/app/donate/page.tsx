'use client';
import { useEffect, useState } from 'react';

export default function DonatePage() {
  const [kofi, setKofi] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setKofi(process.env.NEXT_PUBLIC_KOFI_URL || process.env.KOFI_URL || null);
  }, []);

  const donateStripe = async () => {
    setLoading(true);
    const res = await fetch('/api/create-donation-session', { method: 'POST' });
    const { url } = await res.json();
    window.location.href = url;
  };

  return (
    <div className="max-w-md mx-auto rounded-2xl border p-6 bg-white shadow-sm">
      <h1 className="text-2xl font-bold mb-2">Buy me a coffee ☕</h1>
      {kofi ? (
        <a href={kofi} className="px-4 py-2 rounded-xl bg-slate-900 text-white inline-block">Support on Ko-fi</a>
      ) : (
        <button onClick={donateStripe} disabled={loading} className="px-4 py-2 rounded-xl bg-slate-900 text-white">
          {loading ? 'Redirecting…' : 'One-time tip via Stripe'}
        </button>
      )}
    </div>
  );
}

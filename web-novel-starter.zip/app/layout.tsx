import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "Web Novel",
  description: "Your web novel with memberships, chat, and subscriptions"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen">
        <nav className="sticky top-0 z-50 backdrop-blur bg-white/70 border-b">
          <div className="max-w-5xl mx-auto flex items-center justify-between px-4 py-3">
            <Link href="/" className="font-bold text-xl">Web Novel</Link>
            <div className="flex gap-4 text-sm">
              <Link href="/chapters" className="hover:underline">Chapters</Link>
              <Link href="/members" className="hover:underline">Members</Link>
              <Link href="/donate" className="hover:underline">Buy me a coffee</Link>
              <Link href="/login" className="rounded-lg px-3 py-1.5 bg-slate-900 text-white">Login</Link>
            </div>
          </div>
        </nav>
        <main className="max-w-5xl mx-auto px-4 py-8">{children}</main>
        <footer className="max-w-5xl mx-auto px-4 py-12 text-xs text-slate-500">
          © {new Date().getFullYear()} Web Novel
        </footer>
      </body>
    </html>
  );
}

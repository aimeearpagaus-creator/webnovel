import Stripe from 'stripe';
import { NextResponse } from 'next/server';

export async function POST() {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' as any });
  const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    line_items: [{ price: process.env.STRIPE_PRICE_ID!, quantity: 1 }],
    success_url: `${process.env.SITE_URL}/members`,
    cancel_url: `${process.env.SITE_URL}/chapters`,
  });
  return NextResponse.json({ url: session.url });
}

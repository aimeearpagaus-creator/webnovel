'use client';
import { useEffect, useState } from 'react';
import ChatRoom from '@/components/ChatRoom';
import { supabase } from '@/lib/supabaseClient';
import Link from 'next/link';

export default function MembersPage() {
  const [profile, setProfile] = useState<any>(null);
  useEffect(() => {
    const init = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: prof } = await supabase.from('profiles').select('*').eq('id', user.id).single();
        setProfile(prof);
      }
    };
    init();
  }, []);
  const isPro = !!profile?.is_pro;
  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">Members</h1>
      {!isPro ? (
        <div className="rounded-2xl border p-6 bg-white shadow-sm">
          <p>You need a membership to access the chat.</p>
          <Link href="/chapters/chapter-2" className="mt-3 inline-block px-4 py-2 rounded-xl bg-slate-900 text-white">Subscribe</Link>
        </div>
      ) : (
        <ChatRoom canChat={true} />
      )}
    </div>
  );
}

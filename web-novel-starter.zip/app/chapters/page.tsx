import ChapterCard from "@/components/ChapterCard";

// TODO: Replace with Supabase fetch
const chapters = [
  { slug: 'chapter-1', title: 'Chapter 1: Awakening', summary: 'The journey begins…', is_premium: false },
  { slug: 'chapter-2', title: 'Chapter 2: Trial', summary: 'A test of courage.', is_premium: true }
];

export default function ChaptersPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">Chapters</h1>
      <div className="grid gap-4 md:grid-cols-2">
        {chapters.map(c => <ChapterCard key={c.slug} chapter={c}/>)}
      </div>
    </div>
  );
}

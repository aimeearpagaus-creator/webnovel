'use client';
import { useEffect, useState } from "react";
import Paywall from "@/components/Paywall";
import { supabase } from "@/lib/supabaseClient";
import Image from "next/image";

export default function ChapterDetail({ params }: { params: { slug: string } }) {
  const [profile, setProfile] = useState<any>(null);
  const [chapter, setChapter] = useState<any>(null);

  useEffect(() => {
    const init = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: prof } = await supabase.from('profiles').select('*').eq('id', user.id).single();
        setProfile(prof);
      }
      // TODO: fetch from supabase
      if (params.slug === 'chapter-1') setChapter({ title: 'Chapter 1: Awakening', content: 'This is a free chapter.', is_premium: false });
      else setChapter({ title: 'Chapter 2: Trial', content: 'Premium content goes here…', is_premium: true });
    };
    init();
  }, [params.slug]);

  if (!chapter) return null;
  const isPro = !!profile?.is_pro;

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">{chapter.title}</h1>
      {/* Example art upload display from storage (replace with your uploaded URL) */}
      <div className="rounded-xl overflow-hidden border">
        <Image src="https://picsum.photos/1000/600" alt="Chapter art" width={1000} height={600}/>
      </div>
      {chapter.is_premium && !isPro ? <Paywall isPro={false}/> : (
        <article className="prose max-w-none">
          <p>{chapter.content}</p>
        </article>
      )}
    </div>
  );
}
